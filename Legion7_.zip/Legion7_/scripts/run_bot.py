# Simple CLI to run demo tasks or hook into your bot logic
import click
import subprocess, os, sys

@click.command()
@click.option('--mode', default='demo', help='demo | train | info')
def main(mode):
    if mode == 'demo':
        print('Demo mode: listing top-level files in project...')
        for root, dirs, files in os.walk('.', topdown=True):
            if root.count(os.sep) > 1:  # limit depth
                continue
            print(root, files)
    elif mode == 'train':
        # Example: call the ml training pipeline if dataset exists
        data = 'data/train.csv'
        if os.path.exists(data):
            print('Starting training using ml/train.py...')
            os.system(f'{sys.executable} ml/train.py --data {data} --target label')
        else:
            print('No dataset found at data/train.csv. Add your CSV and rerun.')
    else:
        print('Mode not recognized. Supported: demo, train, info')

if __name__ == '__main__':
    main()
