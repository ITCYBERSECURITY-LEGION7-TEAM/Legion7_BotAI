def test_imports():
    import importlib
    importlib.import_module('ml.data_loader')
    importlib.import_module('ml.model')
    assert True
