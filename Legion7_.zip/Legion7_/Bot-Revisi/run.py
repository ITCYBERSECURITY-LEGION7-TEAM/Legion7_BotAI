#!/usr/bin/env python3
"""
Script utama untuk menjalankan Legion7_BotAI
"""

import os
import sys
import subprocess

# Tambahkan path ke sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def main():
    # Periksa dan install dependencies jika diperlukan
    try:
        from legion7_botai.main import main as bot_main
        from legion7_botai.utils import install_dependencies, check_ollama_installed
        
        # Periksa dependencies Python
        try:
            import requests
            import rich
            import questionary
            import psutil
            import pyfiglet
            import inquirer
        except ImportError:
            print("Menginstall dependencies Python...")
            if not install_dependencies():
                print("Gagal menginstall dependencies. Silakan install manual:")
                print("pip install -r requirements.txt")
                sys.exit(1)
        
        # Periksa Ollama
        if not check_ollama_installed():
            print("Ollama tidak ditemukan. Silakan install Ollama terlebih dahulu.")
            print("Kunjungi: https://ollama.ai untuk instruksi instalasi")
            sys.exit(1)
        
        # Jalankan aplikasi utama
        bot_main()
        
    except KeyboardInterrupt:
        print("\nTerima kasih telah menggunakan Legion7_BotAI!")
    except Exception as e:
        print(f"Error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()
