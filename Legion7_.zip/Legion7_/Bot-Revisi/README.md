# Legion7_BotAI

CLI AI Bot dengan integrasi Ollama dan Llama3, dirancang dengan UI/UX hacker dan animasi loading.

## Fitur

- Auto-detect Ollama dan model Llama
- UI/UX hacker style dengan animasi loading
- Integrasi dengan Ollama API
- Auto-run Ollama service
- Deteksi versi Llama otomatis

## Instalasi

1. Pastikan Python 3.8+ terinstall
2. Install Ollama dari https://ollama.ai
3. Clone repositori ini
4. Install dependencies:

```bash
pip install -r requirements.txt
