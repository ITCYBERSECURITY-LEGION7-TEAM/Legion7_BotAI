import subprocess
import sys

def install_dependencies():
    """Menginstall dependencies yang diperlukan"""
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        return True
    except subprocess.CalledProcessError:
        return False

def check_ollama_installed():
    """Memeriksa apakah Ollama sudah terinstall"""
    try:
        subprocess.run(["ollama", "--version"], capture_output=True, check=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False
