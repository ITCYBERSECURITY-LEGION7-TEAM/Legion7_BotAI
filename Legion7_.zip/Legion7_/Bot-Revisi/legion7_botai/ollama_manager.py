import subprocess
import time
import json
import requests
from rich.console import Console

class OllamaManager:
    def __init__(self, console, ui):
        self.console = console
        self.ui = ui
        self.base_url = "http://localhost:11434"
    
    def check_ollama(self):
        """Memeriksa apakah Ollama terinstall"""
        try:
            result = subprocess.run(["ollama", "--version"], 
                                  capture_output=True, text=True)
            return result.returncode == 0
        except FileNotFoundError:
            return False
    
    def is_ollama_running(self):
        """Memeriksa apakah Ollama service sedang berjalan"""
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=5)
            return response.status_code == 200
        except requests.ConnectionError:
            return False
    
    def start_ollama(self):
        """Menjalankan Ollama service"""
        try:
            # Coba jalankan Ollama sebagai background process
            subprocess.Popen(["ollama", "serve"], 
                           stdout=subprocess.DEVNULL, 
                           stderr=subprocess.DEVNULL)
            
            # Tunggu hingga service ready
            for _ in range(30):  # Timeout 30 detik
                if self.is_ollama_running():
                    return True
                time.sleep(1)
            
            return False
        except Exception as e:
            self.console.print(f"[red]Gagal menjalankan Ollama: {str(e)}[/red]")
            return False
    
    def detect_llama_model(self):
        """Mendeteksi model Llama yang tersedia"""
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=10)
            if response.status_code == 200:
                models = response.json().get("models", [])
                for model in models:
                    if "llama" in model["name"].lower():
                        return model["name"]
            return None
        except requests.ConnectionError:
            return None
    
    def download_model(self, model_name):
        """Mendownload model Ollama"""
        try:
            self.console.print(f"[yellow]Mendownload model {model_name}...[/yellow]")
            process = subprocess.Popen(["ollama", "pull", model_name],
                                     stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE,
                                     text=True)
            
            # Tampilkan progress
            while True:
                output = process.stdout.readline()
                if output == '' and process.poll() is not None:
                    break
                if output:
                    self.console.print(f"[cyan]{output.strip()}[/cyan]")
            
            return process.returncode == 0
        except Exception as e:
            self.console.print(f"[red]Gagal mendownload model: {str(e)}[/red]")
            return False
    
    def generate_response(self, model_name, prompt):
        """Generate respons dari model"""
        try:
            payload = {
                "model": model_name,
                "prompt": prompt,
                "stream": False
            }
            
            response = requests.post(f"{self.base_url}/api/generate", 
                                   json=payload, 
                                   timeout=60)
            
            if response.status_code == 200:
                return response.json().get("response", "Tidak ada respons")
            else:
                return f"Error: {response.status_code} - {response.text}"
        except Exception as e:
            return f"Error generating response: {str(e)}"