#!/usr/bin/env python3
import os
import sys
import time
import subprocess
import requests
import json
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from rich.panel import Panel
from rich.markdown import Markdown
from rich.style import Style
import questionary
import psutil

# Import modul internal
from .ollama_manager import OllamaManager
from .ui_ux import HackerUI

def main():
    console = Console()
    ui = HackerUI(console)
    
    # Tampilkan splash screen
    ui.show_splash()
    
    # Periksa dan install dependencies
    if not check_dependencies():
        console.print("[red]Beberapa dependencies tidak terpenuhi. Silakan install manual.[/red]")
        sys.exit(1)
    
    # Inisialisasi OllamaManager
    ollama = OllamaManager(console, ui)
    
    # Periksa status Ollama
    if not ollama.check_ollama():
        console.print("[red]Ollama tidak ditemukan. Silakan install Ollama terlebih dahulu.[/red]")
        sys.exit(1)
    
    # Jalankan Ollama jika belum berjalan
    if not ollama.is_ollama_running():
        console.print("Menjalankan Ollama...")
        ollama.start_ollama()
    
    # Deteksi model Llama
    model_name = ollama.detect_llama_model()
    
    if not model_name:
        console.print("[yellow]Model Llama tidak ditemukan. Ingin mendownload model?[/yellow]")
        if questionary.confirm("Download model Llama3?").ask():
            ollama.download_model("llama3")
            model_name = "llama3"
        else:
            console.print("[red]Tidak dapat melanjutkan tanpa model.[/red]")
            sys.exit(1)
    
    console.print(f"[green]Model terdeteksi: {model_name}[/green]")
    
    # Main loop interaksi
    while True:
        try:
            prompt = questionary.text(
                "🤖 Anda:",
                qmark="",
                instruction="(Ketik 'quit' untuk keluar atau 'clear' untuk membersihkan layar)"
            ).ask()
            
            if prompt.lower() == 'quit':
                break
            elif prompt.lower() == 'clear':
                console.clear()
                ui.show_splash()
                continue
            elif not prompt.strip():
                continue
            
            # Tampilkan animasi loading
            with ui.create_progress() as progress:
                task = progress.add_task("[cyan]Thinking...", total=100)
                
                # Simulasi proses thinking
                for i in range(100):
                    progress.update(task, advance=1)
                    time.sleep(0.02)
            
            # Dapatkan respons dari Ollama
            response = ollama.generate_response(model_name, prompt)
            
            # Tampilkan respons
            ui.display_response(response)
            
        except KeyboardInterrupt:
            console.print("\n[yellow]Interrupted by user. Type 'quit' to exit.[/yellow]")
        except Exception as e:
            console.print(f"[red]Error: {str(e)}[/red]")

def check_dependencies():
    """Memeriksa apakah semua dependencies terinstall"""
    try:
        import requests
        import rich
        import questionary
        import psutil
        import pyfiglet
        import inquirer
        return True
    except ImportError as e:
        print(f"Dependency missing: {e}")
        return False

if __name__ == "__main__":
    main()
