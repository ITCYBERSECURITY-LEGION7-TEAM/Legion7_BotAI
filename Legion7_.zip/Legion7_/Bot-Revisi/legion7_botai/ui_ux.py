import time
import random
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from rich.panel import Panel
from rich.markdown import Markdown
from rich.style import Style
import pyfiglet

class HackerUI:
    def __init__(self, console):
        self.console = console
    
    def show_splash(self):
        """Menampilkan splash screen hacker style dengan banner Legion7_BotAI"""
        self.console.clear()
        
        # Tampilkan banner utama dengan pyfiglet
        ascii_banner = pyfiglet.figlet_format("Legion7_BotAI", font="slant")
        self.console.print(f"[bold green]{ascii_banner}[/bold green]")
        
        # Tampilkan sub-banner
        sub_banner = pyfiglet.figlet_format("AI Assistant", font="small")
        self.console.print(f"[bright_cyan]{sub_banner}[/bright_cyan]")
        
        # Tampilkan informasi panel
        info_panel = Panel.fit(
            "[bold white]CLI AI Bot dengan Ollama dan Llama3[/bold white]\n"
            "[yellow]Version 0.1.0 - Hacker Mode Enabled[/yellow]\n\n"
            "[bright_white]Developed by: Legion7 Development Team[/bright_white]",
            style="bright_green",
            border_style="green"
        )
        self.console.print(info_panel)
        
        # Tampilkan hacker-style initialization
        self.console.print("[bright_green]Initializing system protocols...[/bright_green]")
        self.simulate_hacker_loading()
    
    def simulate_hacker_loading(self):
        """Simulasi loading style hacker yang lebih detail"""
        messages = [
            "Bypassing security protocols...",
            "Accessing mainframe...",
            "Decrypting neural network...",
            "Loading AI modules...",
            "Establishing quantum connection...",
            "Initializing Llama3 cortex...",
            "Calibrating language matrices...",
            "Synchronizing data streams...",
            "Optimizing response algorithms...",
            "Finalizing system checks..."
        ]
        
        with self.console.status("[bold green]Legion7_BotAI System Initialization[/bold green]", spinner="dots") as status:
            for i, msg in enumerate(messages):
                status.update(status=f"[cyan]{msg}[/cyan] [yellow]({i+1}/{len(messages)})[/yellow]")
                time.sleep(0.5 + random.random() * 0.3)  # Variasi waktu loading
        
        # Animasi penyelesaian
        with self.console.status("[bright_green]Finalizing startup sequence...[/bright_green]") as status:
            time.sleep(1.2)
        
        self.console.print("[bold bright_green]✓ Legion7_BotAI System ready![/bold bright_green]")
        self.console.print("[bright_white]Type your message or 'quit' to exit.[/bright_white]")
        self.console.print("[bright_white]" + "=" * 60 + "[/bright_white]")
    
    def create_progress(self):
        """Membuat progress bar dengan style hacker yang konsisten"""
        return Progress(
            SpinnerColumn("dots", style="green"),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(complete_style="green", finished_style="bright_green"),
            TaskProgressColumn(),
            console=self.console,
            expand=True
        )
    
    def display_response(self, response):
        """Menampilkan respons AI dengan style yang menarik dan konsisten"""
        # Panel untuk respons AI dengan border yang sesuai
        panel = Panel(
            Markdown(response),
            title="[bold green]Legion7_BotAI Response[/bold green]",
            subtitle="[italic yellow]Powered by Ollama & Llama3[/italic yellow]",
            style="bright_white on black",
            border_style="green",
            padding=(1, 2)
        )
        self.console.print(panel)
    
    def show_error(self, message):
        """Menampilkan pesan error dengan style yang konsisten"""
        self.console.print(Panel.fit(
            f"[red]{message}[/red]",
            title="[bold red]Legion7_BotAI ERROR[/bold red]",
            border_style="red",
            style="white on dark_red"
        ))
    
    def show_warning(self, message):
        """Menampilkan pesan peringatan dengan style yang konsisten"""
        self.console.print(Panel.fit(
            f"[yellow]{message}[/yellow]",
            title="[bold yellow]Legion7_BotAI WARNING[/bold yellow]",
            border_style="yellow",
            style="black on bright_yellow"
        ))
    
    def show_info(self, message):
        """Menampilkan pesan informasi dengan style yang konsisten"""
        self.console.print(Panel.fit(
            f"[blue]{message}[/blue]",
            title="[bold blue]Legion7_BotAI INFO[/bold blue]",
            border_style="blue",
            style="white on dark_blue"
        ))
    
    def show_user_input(self, message):
        """Menampilkan input pengguna dengan style yang konsisten"""
        self.console.print(Panel.fit(
            f"[bright_cyan]{message}[/bright_cyan]",
            title="[bold bright_cyan]Your Message[/bold bright_cyan]",
            border_style="bright_cyan",
            style="black on bright_cyan"
        ))
    
    def show_exit_message(self):
        """Menampilkan pesan keluar yang sesuai dengan tema"""
        farewell = pyfiglet.figlet_format("Goodbye!", font="small")
        self.console.print(f"[bold green]{farewell}[/bold green]")
        self.console.print(Panel.fit(
            "[bold white]Legion7_BotAI session terminated.[/bold white]\n"
            "[yellow]Thank you for using our AI assistant![/yellow]",
            style="bright_green",
            border_style="green"
        ))