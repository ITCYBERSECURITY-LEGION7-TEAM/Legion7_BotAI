import argparse
from ml.data_loader import load_csv
from ml.model import build_model, save_model
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import joblib

def train(path, target, test_size=0.2, random_state=42):
    X, y = load_csv(path, target_col=target)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=random_state)
    model = build_model(random_state=random_state)
    model.fit(X_train, y_train)
    preds = model.predict(X_test)
    acc = accuracy_score(y_test, preds)
    save_model(model)
    print(f'Training complete. test accuracy={acc:.4f}')
    return acc

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', required=True, help='CSV path')
    parser.add_argument('--target', required=True, help='target column')
    args = parser.parse_args()
    train(args.data, args.target)
