import pandas as pd
import os

def load_csv(path, target_col=None, nrows=None):
    """Simple CSV loader that returns X, y if target_col provided."""
    df = pd.read_csv(path, nrows=nrows)
    if target_col and target_col in df.columns:
        y = df[target_col]
        X = df.drop(columns=[target_col])
        return X, y
    return df

if __name__ == '__main__':
    print('Data loader example.')
